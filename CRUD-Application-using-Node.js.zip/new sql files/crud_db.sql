-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2019 at 01:12 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` varchar(100) NOT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `product_category` varchar(100) DEFAULT NULL,
  `product_desc` varchar(400) DEFAULT NULL,
  `product_image_path` varchar(100) DEFAULT NULL,
  `product_price` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_category`, `product_desc`, `product_image_path`, `product_price`, `user_id`) VALUES
('09d899d6-2d4f-4d23-bc1b-f8f609f41c3f', 'Kamran', 'Humascscs', 'Good Cricket', 'frands.jpg', 420, NULL),
('5c7a757e-6d3d-42ef-a8d4-8b513a69f014', 'laptop', 'Laptop', 'heavy Display', 'images (1).jfif', 24000, '4'),
('8733edcc-590a-4ac1-8768-5e71489a566d', 'car', 'vehicals', 'brand new', 'car.jfif', 2400000, '4'),
('8ace5353-39ec-4cf4-8352-0786997f0270', 'S10', 'mobile', 'good Quality', 's10.jfif', 120000, '6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
