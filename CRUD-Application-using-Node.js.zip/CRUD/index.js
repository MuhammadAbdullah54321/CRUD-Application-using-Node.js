const path = require('path');
const fs = require('fs');
const uuid = require('uuid-random');
const bodyParser = require('body-parser');
const formidable = require('formidable');
const express = require('express');
const session = require('express-session');
const mysql = require('mysql');
const app = express();
 

//Create connection for Showing product data
const conn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'crud_db'
});

//Create connection for Login Authentication 
var connection = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : '',
	database : 'nodelogin'
});

app.use(session({
	secret: 'topsecret',
	resave: true,
	saveUninitialized: true
}));


//connect to database
conn.connect((err) =>{
  if(err) throw err;
  console.log('Mysql Connected...');
});
 
//set views file
app.set('views',path.join(__dirname,'views'));
//set view engine
app.set('view engine', 'hbs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
//set public folder as static folder for static file
app.use('/assets',express.static(__dirname + '/public'));
app.use('/static', express.static(path.join(__dirname+'/views/images')));
 



app.get('/', function(req, res) {
  if(req.session.loggedin) res.redirect('/home');  
  else res.sendFile(path.join(__dirname + '/login.html'));
});

app.get('/signup', function(req, res) {  
  res.sendFile(path.join(__dirname+'/signup.html'));
});

app.post('/signup-data', function(request, response) {  
  var username = request.body.username;
  var password = request.body.password;
  var rpassword = request.body.rpassword;
  var email = request.body.email;
  var role = request.body.role;
	if (username && email && password && rpassword) {
    if(password === rpassword){
      let data = { 
        username: username,
        password: password,
        email: email,
        role: role
    };


      var q = 'INSERT INTO accounts SET ?';
      connection.query(q, data, function(err, results, fields) {
         if(err) throw err;
        request.session.loggedin = true;
          request.session.username = username;
          response.redirect('/home');
          response.end();
      });
    }
    else{
      response.send('Password doesnt match. <a href="/signup">Go Back</a> ');
    }
	} else {
		response.send('Please enter Username and Password!');
		response.end();
	}});


app.get('/signout', function(req, res) {
  res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
  req.session.loggedin = false;
  res.redirect('/');
});

app.post('/auth', function(request, response) {
	var username = request.body.username;
  var password = request.body.password;
  
	if (username && password) {
		connection.query('SELECT * FROM accounts WHERE username = ? AND password = ?', [username, password], function(error, results, fields) {
			if (results.length > 0) {
        request.session.customId = results[0].id;
				request.session.loggedin = true;
				request.session.username = username;
				response.redirect('/home');
			} else {
				response.send('Incorrect Username and/or Password! <br /><a href="/" style="color:red">Login  Again</a>');
			}			
			response.end();
		});
	} else {
		response.redirect('/');
	}
});



//route for homepage
app.get('/home',(req, response) => {
  if(req.session.loggedin){
    response.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    let sql_acc = "SELECT * FROM accounts WHERE id="+req.session.customId+";";
        let query2 = connection.query(sql_acc, (error, res, fields)=>{
          req.session.role = res[0].role;
          req.session.username1 = res[0].username;
              if(res[0].role == 'seller'){
                let sql = "SELECT * FROM product WHERE user_id="+req.session.customId+";";
                let query = conn.query(sql, (err, results) => {
                  response.render('product_view',{results: results, session:req.session});
                });
              }
              else if(res[0].role == 'buyer'){
                let sql = "SELECT * FROM product";
                let query = conn.query(sql, (err, results) => {
                  response.render('buyer',{results: results, session:req.session});
              }
          )};       
 
    });
  }
  else
  {
    response.redirect('/');
  }
});
 


//route for insert data
app.post('/save', (req, res) => {
  var form = new formidable.IncomingForm();  
  
    form.parse(req, function (err, fields, files) {
      var id = uuid();
      let data = { 
        product_id: id,
        product_name: fields.product_name.valueOf(), 
        product_category: fields.product_category.valueOf(), 
        product_desc: fields.product_desc.valueOf(), 
        product_price: fields.product_price.valueOf(),
        user_id: req.session.customId,
        product_image_path: "default"
    };
    let sql = "INSERT INTO product SET ?";
            let query = conn.query(sql, data,(err, results) => {
                if(err) throw err;
                else console.log(data);
                //res.redirect('/');
            });

            // Here is the code for storing Images 
      var oldpath = files.product_image.path;
      var newpath = 'C:/Users/domain1/Desktop/CRUD/views/images/' + files.product_image.name;
      fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        else{
            console.log('extra line');
            console.log(newpath);
              let sql = 'UPDATE product SET product_image_path ="'+files.product_image.name+'" WHERE product_id="'+id+'";';
              console.log(sql);
              let query = conn.query(sql, (err, results) => {
                if(err) throw err;
                console.log('path added in DB');
                res.redirect('/');
              });    
        }
      });
    });
 /**/

  
});
 
//route for update data
app.post('/update',(req, res) => {
  let sql = "UPDATE product SET product_name='"+req.body.product_name+"', product_price='"+req.body.product_price+"', product_category='"+req.body.product_category+"', product_desc='"+req.body.product_desc+"' WHERE product_id='"+req.body.id+"';";
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    console.log(sql);
    res.redirect('/');
  });
});
 
//route for delete data
app.post('/delete',(req, res) => {
  let sql = 'DELETE FROM product WHERE product_id="'+req.body.product_id+'";';
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
      res.redirect('/');
  });
});
 
//server listening
app.listen(4000, () => {
  console.log('Server is running at port 4000');
  
});